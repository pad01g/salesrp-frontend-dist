import{r as t}from"./index-Ckl4xwI-.js";const e=()=>{const r=t("FirebaseAnalytics");return{async logEvent(a){await r.logEvent({name:a.name,params:a.params})}}};export{e as createCapacitorAnalytics};
