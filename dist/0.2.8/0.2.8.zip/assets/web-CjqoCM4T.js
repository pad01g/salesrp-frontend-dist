import{W as n}from"./index-Ckl4xwI-.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
