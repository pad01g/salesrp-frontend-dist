import{W as n}from"./index-Cl5EbRc4.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
