import{W as n}from"./index-BbsDCajR.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
