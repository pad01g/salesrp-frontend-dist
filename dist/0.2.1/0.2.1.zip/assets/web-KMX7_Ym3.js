import{W as n}from"./index-Bl-5mJQM.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
