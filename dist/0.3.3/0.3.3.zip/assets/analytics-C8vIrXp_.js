import{r as t}from"./index-69zOqose.js";const e=()=>{const r=t("FirebaseAnalytics");return{async logEvent(a){await r.logEvent({name:a.name,params:a.params})}}};export{e as createCapacitorAnalytics};
