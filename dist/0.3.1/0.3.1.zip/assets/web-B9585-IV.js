import{W as n}from"./index-utLgvC-d.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
